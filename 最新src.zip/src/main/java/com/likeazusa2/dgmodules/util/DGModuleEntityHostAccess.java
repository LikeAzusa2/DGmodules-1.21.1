package com.likeazusa2.dgmodules.util;

import com.brandon3055.draconicevolution.api.capability.ModuleHost;

public interface DGModuleEntityHostAccess {
    ModuleHost dgmodules$getHost();
}
